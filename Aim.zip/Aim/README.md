IN PROGRESS: 
Thomas / CameraX function: https://www.youtube.com/watch?v=12_iKwGIP64
Adnil / Firebase database setup with user profiles, log in, friend adding system: https://www.youtube.com/watch?v=idbxxkF1l6k&pp=ygUxYW5kcm9pZCBzdHVkaW8gZmlyZWJhc2UgbG9naW4gYW5kIHJlZ2lzdGVyIGtvdGxpbg%3D%3D https://www.youtube.com/watch?v=y4npeX35B34&pp=ygU1YW5kcm9pZCBzdHVkaW8gZmlyZWJhc2UgZnJpZW5kIGFuZCB1c2VyIHN5c3RlbSBrb3RsaW4%3D https://www.youtube.com/watch?v=pLnhnHwLkYo&pp=ygU1YW5kcm9pZCBzdHVkaW8gZmlyZWJhc2UgZnJpZW5kIGFuZCB1c2VyIHN5c3RlbSBrb3RsaW4%3D
Taiger / RecyclerView and the main app layout with feed
TO DO:
Calendar, user profiles, database for images, friend adding system, leaderboard, notification reminders.
